import React from 'react';

import './Intro.css';

const Intro = () => (
  <div>
    Intro
  </div>
);

export default Intro;
